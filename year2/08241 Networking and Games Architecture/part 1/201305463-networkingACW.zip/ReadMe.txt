Client:
My client is in the location folder and the executable is named location.exe. The folder also contains the .cs file for the client.

Server:
My server is in the locationserver folder and the executable is named locationserver.exe. the folder also contains the .cs files 
including the classes named Server.cs, Handle.cs and Program.cs. 

Progress:
My client and server pass all the basic tests upto and including threading and saving the dictionary and some of the advanced tests across the board.
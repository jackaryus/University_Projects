﻿using System;

namespace locationserver
{
    class Program
    {
        static void Main(string[] args)
        {
            Server server = new Server();

        }

    }
}

var __extends = this.__extends || function (child, parent) 
{
	function Proxy() 
	{ 
		this.constructor = child; 
	}
	Proxy.prototype = parent.prototype;
	child.prototype = new Proxy();
}
